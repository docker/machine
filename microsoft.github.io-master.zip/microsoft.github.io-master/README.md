microsoft.github.io
===================

As Microsoft's open source presence and volume of released source code up on GitHub has
increased, we've reimagined the portal and index for our repos.

Today you can find, filter and review all sorts of open source up at https://opensource.microsoft.com.

At this time the site also continues to hold the official Microsoft Open Source Code of Conduct policy and
FAQ.

Feel free to email [opensource@microsoft.com](mailto:opensource@microsoft.com) if you have any questions about this site or Microsoft GitHub
organizations in general.


        microsoft.github.io/README.md
      
