﻿namespace BinarySerialization.Test.Count
{
    public class PaddedConstSizeListItemClass
    {
        public byte Value { get; set; }
    }
}
