﻿namespace BinarySerialization.Test.Misc
{
    public class AbstractClassContainer
    {
        public AbstractClass Content { get; set; }
    }
}