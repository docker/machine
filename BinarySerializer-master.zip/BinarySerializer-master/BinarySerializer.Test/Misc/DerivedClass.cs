﻿namespace BinarySerialization.Test.Misc
{
    public class DerivedClass : AbstractClass
    {
        public int Value { get; set; }
    }
}