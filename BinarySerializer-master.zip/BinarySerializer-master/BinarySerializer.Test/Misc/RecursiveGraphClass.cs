﻿namespace BinarySerialization.Test.Misc
{
    public class RecursiveGraphClass
    {
        public RecursiveGraphClass Child { get; set; }
    }
}