﻿namespace BinarySerialization.Test.Misc
{
    public class InvalidButIgnoredTypeClass
    {
        public int A;

        public int B;
    }
}
