﻿namespace BinarySerialization.Test.Misc
{
    public class SkipableContainerClass
    {
        public SkipableClass Skipable { get; set; }
    }
}
