﻿namespace BinarySerialization.Test.Misc
{
    public class DontFlushTooMuchInternalClass
    {
        public int Value { get; set; }
    }
}
