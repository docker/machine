﻿using System.Collections.Generic;

namespace BinarySerialization.Test.Length
{
    public class ContainedCollection
    {
        public List<string> Collection { get; set; }
    }
}