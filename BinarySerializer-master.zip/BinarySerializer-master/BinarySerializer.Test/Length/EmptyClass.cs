﻿namespace BinarySerialization.Test.Length
{
    public class EmptyClass
    {
        public EmptyInternalClass Internal { get; set; }
    }
}
