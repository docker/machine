﻿namespace BinarySerialization.Test.Value
{
    public abstract class TcpOptionBase
    {
    }
}
