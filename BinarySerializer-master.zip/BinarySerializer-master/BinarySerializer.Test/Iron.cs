﻿namespace BinarySerialization.Test
{
    public class Iron : Chemical
    {
        public Iron() : base("Fe")
        {
        }
    }
}