﻿using System.Collections.Generic;

namespace BinarySerialization.Test
{
    public class ImplictTermination
    {
        public List<byte> Data { get; set; }
    }
}