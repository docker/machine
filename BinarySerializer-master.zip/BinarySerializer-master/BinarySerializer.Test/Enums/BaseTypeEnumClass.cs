namespace BinarySerialization.Test.Enums
{
    public class BaseTypeEnumClass
    {
        public BaseTypeEnumValues Field { get; set; }
    }
}