namespace BinarySerialization.Test.Enums
{
    public enum BaseTypeEnumValues : byte
    {
        A,
        B,
        C
    }
}