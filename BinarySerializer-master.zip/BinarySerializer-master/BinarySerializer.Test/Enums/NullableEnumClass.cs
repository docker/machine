﻿namespace BinarySerialization.Test.Enums
{
    public class NullableEnumClass
    {
        public BaseTypeEnumValues? Field { get; set; }
    }
}