﻿namespace BinarySerialization.Test.Enums {
    public class BaseTypeSignedEnumClass
    {
        public BaseTypeSignedEnumValues Field { get; set; }
    }
}