﻿namespace BinarySerialization.Test.Subtype
{
    public class ThrowOnAbstractTypeWithNoSubtypeClass
    {
        public Superclass Superclass { get; set; }
    }
}