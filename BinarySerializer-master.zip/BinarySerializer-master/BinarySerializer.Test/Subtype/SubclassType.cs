namespace BinarySerialization.Test.Subtype
{
    public enum SubclassType : byte
    {
        A,
        B,
        C
    }
}