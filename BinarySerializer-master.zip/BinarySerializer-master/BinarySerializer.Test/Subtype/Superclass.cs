namespace BinarySerialization.Test.Subtype
{
    public abstract class Superclass
    {
        public int SomeSuperStuff { get; set; }
    }
}