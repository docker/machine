﻿namespace BinarySerialization.Test.Subtype
{
    public class DefaultSubtypeClass : Superclass
    {
        public byte[] Data { get; set; }
    }
}
