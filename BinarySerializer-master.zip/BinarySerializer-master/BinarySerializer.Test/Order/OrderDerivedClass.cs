﻿namespace BinarySerialization.Test.Order
{
    public class OrderDerivedClass : OrderBaseClass
    {
        public byte Second { get; set; }
    }
}