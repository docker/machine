﻿namespace BinarySerialization.Test.Endianness
{
    public class EndiannessClass
    {
        public short Short { get; set; }
    }
}