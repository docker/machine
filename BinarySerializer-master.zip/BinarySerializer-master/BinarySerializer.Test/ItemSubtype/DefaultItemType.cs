﻿namespace BinarySerialization.Test.ItemSubtype
{
    public class DefaultItemType : IItemSubtype
    {
        public byte[] Data { get; set; }
    }
}
