﻿namespace BinarySerialization.Test.ItemSubtype
{
    public class ItemTypeA : IItemSubtype
    {
        public ushort Value { get; set; }
    }
}
