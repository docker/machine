﻿namespace BinarySerialization.Test.Issues.Issue30
{
    public enum MessageType : ushort
    {
        Nok = 0,
        Ack = 1
    }
}