﻿namespace BinarySerialization.Test.Issues.Issue30
{
    public enum PayloadType : uint
    {
        UnDefined = 0,
        INIT = 1,
        STAMR = 100
    }
}