﻿namespace BinarySerialization.Test.Issues.Issue24
{
    public class Bin1Data
    {
        public int Value { get; set; }
    }
}