﻿namespace BinarySerialization.Test.Issues.Issue12
{
    public class BeerChunk : Chunk
    {
    }
}