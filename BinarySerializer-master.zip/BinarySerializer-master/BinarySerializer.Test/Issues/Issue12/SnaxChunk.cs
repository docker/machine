﻿namespace BinarySerialization.Test.Issues.Issue12
{
    public class SnaxChunk : Chunk
    {
    }
}