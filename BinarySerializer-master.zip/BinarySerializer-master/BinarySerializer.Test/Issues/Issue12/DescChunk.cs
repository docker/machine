﻿namespace BinarySerialization.Test.Issues.Issue12
{
    public class DescChunk : Chunk
    {
        public string Description { get; set; }
    }
}