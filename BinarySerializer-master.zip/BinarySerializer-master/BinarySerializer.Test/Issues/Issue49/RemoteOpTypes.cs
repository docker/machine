﻿namespace BinarySerialization.Test.Issues.Issue49
{
    public enum RemoteOpTypes
    {
        Invoke,
        Command,
        Result
    }

    public enum RemoteInvokeAction
    {
        
    }

    public enum MessageType
    {
        
    }
}
