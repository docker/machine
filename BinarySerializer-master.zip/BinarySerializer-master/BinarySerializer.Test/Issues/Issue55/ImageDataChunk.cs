namespace BinarySerialization.Test.Issues.Issue55
{
    public class ImageDataChunk : Chunk { }
}