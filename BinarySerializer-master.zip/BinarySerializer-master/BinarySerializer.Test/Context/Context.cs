﻿namespace BinarySerialization.Test.Context
{
    public class Context
    {
        public bool SerializeCondtion { get; set; }

        public int UnorderedField { get; set; }
    }
}