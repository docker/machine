﻿using BinarySerialization.Graph.TypeGraph;

namespace BinarySerializer.Editor.ViewModels
{
    public class CollectionViewModelBase : FieldViewModel
    {
        public CollectionViewModelBase(TypeNode typeNode) : base(typeNode)
        {
        }
    }
}
