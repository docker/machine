﻿namespace BinarySerializer.Editor.Test
{
    public enum PngColorMode : byte
    {
        Greyscale = 0,
        Truecolor = 2,
        Indexed = 3,
        GreyscaleWithAlpha = 4,
        TruecolorWithAlpha = 6
    }
}
