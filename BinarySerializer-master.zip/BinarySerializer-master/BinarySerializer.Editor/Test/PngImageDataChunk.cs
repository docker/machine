﻿namespace BinarySerializer.Editor.Test
{
    public class PngImageDataChunk : PngChunk
    {
        public byte[] Data { get; set; }
    }
}
