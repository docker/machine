package com.android.adobot.http;

import java.util.HashMap;

/**
 * Created by adones on 2/17/17.
 */

public interface HttpCallback {
    void onResponse (HashMap response);
}
