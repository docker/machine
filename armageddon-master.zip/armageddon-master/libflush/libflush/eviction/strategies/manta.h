/* See LICENSE file for license and copyright information */

/* Nexus 10 */
#define NUMBER_OF_SETS 1024
#define LINE_LENGTH_LOG2 6
#define LINE_LENGTH 64
#define ES_EVICTION_COUNTER 10
#define ES_NUMBER_OF_ACCESSES_IN_LOOP 2
#define ES_DIFFERENT_ADDRESSES_IN_LOOP 2
