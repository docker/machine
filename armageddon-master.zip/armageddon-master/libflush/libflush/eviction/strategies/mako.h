/* See LICENSE file for license and copyright information */

/* Nexus 4 */
#define NUMBER_OF_SETS 2048
#define LINE_LENGTH_LOG2 7
#define LINE_LENGTH 128
#define ES_EVICTION_COUNTER 12
#define ES_NUMBER_OF_ACCESSES_IN_LOOP 1
#define ES_DIFFERENT_ADDRESSES_IN_LOOP 2
