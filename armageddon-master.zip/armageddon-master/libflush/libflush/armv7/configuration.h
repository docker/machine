/* See LICENSE file for license and copyright information */

#ifndef ARM_V7_CONFIGURATION_H
#define ARM_V7_CONFIGURATION_H

#define CYCLE_COUNTER_DIV_64 0

#endif // ARM_V7_CONFIGURATION_H
