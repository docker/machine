/* See LICENSE file for license and copyright information */

#ifndef ARM_V8_INTERNAL_H
#define ARM_V8_INTERNAL_H

void arm_v8_timing_init(void);
void arm_v8_timing_terminate(void);

#endif // ARM_V8_INTERNAL_H
