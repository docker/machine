API
===

.. doxygenfile:: libflush/libflush.h
