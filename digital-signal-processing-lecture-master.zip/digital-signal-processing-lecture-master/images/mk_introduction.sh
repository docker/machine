latex -shell-escape introduction.tex
convert -units PixelsPerInch -density 144 -resize 700 introduction-1.png ../introduction/DSP.png

