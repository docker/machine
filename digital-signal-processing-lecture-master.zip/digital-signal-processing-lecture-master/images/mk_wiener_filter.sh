latex -shell-escape wiener_filter.tex
convert -units PixelsPerInch -density 144 -resize 600 wiener_filter-1.png ../random_signals_LTI_systems/model_wiener_filter.png 
