latex -shell-escape random_signals.tex
convert -units PixelsPerInch -density 144 -resize 600 random_signals-1.png ../random_signals/measurement_channel.png
convert -units PixelsPerInch -density 144 -resize 500 random_signals-2.png ../random_signals/communication_channel.png


