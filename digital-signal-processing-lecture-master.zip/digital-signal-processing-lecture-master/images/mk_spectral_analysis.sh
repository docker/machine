latex -shell-escape spectral_analysis.tex
convert -units PixelsPerInch -density 144 -resize 600 spectral_analysis-1.png ../spectral_analysis_deterministic_signals/Fourier_transforms.png

