---
name: "\U0001F41BBug Report"
about: Something isn't working

---

<!-- Delete any sections below that are not relevant. -->

# Bug Report

## eBayUI Version: x.x.x

## Description
<!-- What's the bug? Include steps to reproduce, actual vs. expected behavior, etc. -->

## Workaround
<!-- Is there a known workaround? If so, what is it? -->

## Screenshots
<!-- Upload screenshots if appropriate. -->
