---
name: "\U0001F680Feature Request"
about: Suggest an idea for this project

---

<!-- Delete any sections below that are not relevant. -->

# Feature Request

## Description
<!-- What is the new feature? What problem does it solve? -->

## Context
<!-- Provide additional contextual information if needed. -->

## Screenshots
<!-- Upload screenshots if appropriate. -->
