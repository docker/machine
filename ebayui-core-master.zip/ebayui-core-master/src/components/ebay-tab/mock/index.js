const headings = [{}, {}, {}];
const panels = [{}, {}, {}];

const fakeHeadings = [{ href: '#' }, { href: '#' }, { href: '#' }];

module.exports = { headings, panels, fakeHeadings };
