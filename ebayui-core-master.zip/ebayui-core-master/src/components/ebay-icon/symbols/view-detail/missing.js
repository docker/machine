if (typeof window !== 'undefined') console.error('ds6 icon not found: view-detail');
