if (typeof window !== 'undefined') console.error('ds4 icon not found: info');
