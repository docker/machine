# ISOs folder

Place all ISOs that AutomatedLab should find automatically in here.
