function Set-UnattendedYastLocalIntranetSites
{
	param (
		[Parameter(Mandatory = $true)]
		[string[]]$Values
	)
}