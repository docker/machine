configuration = { 
"email" : "jon.demasi@colorado.edu", 
"usecaching" : "true",
"dbloc" : "/home/jonathan/somestuff.db",
}
