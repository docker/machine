configuration = { 
"email" : "tnphung@ucla.edu", 
"usecaching" : "true",
"dbloc" : "/home/ubuntu/somestuff.db",
}
