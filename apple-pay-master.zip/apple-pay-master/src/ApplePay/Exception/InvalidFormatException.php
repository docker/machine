<?php

namespace PayU\ApplePay\Exception;

use Exception;

class InvalidFormatException extends Exception
{



}