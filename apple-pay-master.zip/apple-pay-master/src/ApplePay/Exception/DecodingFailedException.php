<?php

namespace PayU\ApplePay\Exception;

use Exception;

class DecodingFailedException extends Exception
{



}