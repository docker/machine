<?php

namespace PayU\ApplePay\Decoding\SignatureVerifier\Exception;

use Exception;

class SignatureException extends Exception
{
}